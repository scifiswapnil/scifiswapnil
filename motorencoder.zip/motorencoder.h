#include <Arduino.h>

class MotorEncoder {
  public:
    MotorEncoder(int dir_pin, int pwm_pin, int enc_a_pin, int enc_b_pin);
    void set_target_velocity(float target_velocity);
    void control_motor();

  private:
    int _dir_pin;
    int _pwm_pin;
    int _enc_a_pin;
    int _enc_b_pin;
    volatile long _enc_count;
    volatile boolean _enc_a_last;
    volatile unsigned long _prev_time;
    volatile long _prev_count;
    volatile float _velocity;
    float _target_velocity;
    float _pwm_value;
    const float _k_p = 5.0;  // Proportional gain for PWM control
};

MotorEncoder::MotorEncoder(int dir_pin, int pwm_pin, int enc_a_pin, int enc_b_pin) {
  _dir_pin = dir_pin;
  _pwm_pin = pwm_pin;
  _enc_a_pin = enc_a_pin;
  _enc_b_pin = enc_b_pin;
  _enc_count = 0;
  _enc_a_last = false;
  _prev_time = micros();
  _prev_count = 0;
  _velocity = 0;
  _target_velocity = 0;
  _pwm_value = 0;
  pinMode(_dir_pin, OUTPUT);
  pinMode(_pwm_pin, OUTPUT);
  pinMode(_enc_a_pin, INPUT_PULLUP);
  pinMode(_enc_b_pin, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(_enc_a_pin), MotorEncoder::enc_interrupt, CHANGE);
}

void MotorEncoder::set_target_velocity(float target_velocity) {
  _target_velocity = target_velocity;
}

void MotorEncoder::control_motor() {
  unsigned long cur_time = micros();
  long cur_count = _enc_count;
  long count_diff = cur_count - _prev_count;
  float time_diff = (cur_time - _prev_time) / 1000000.0;
  _velocity = count_diff / time_diff;
  _prev_time = cur_time;
  _prev_count = cur_count;

  float error = _target_velocity - _velocity;
  _pwm_value = error * _k_p;

  digitalWrite(_dir_pin, _target_velocity >= 0 ? HIGH : LOW);

  if (_pwm_value < 0) {
    _pwm_value = 0;
  } else if (_pwm_value > 255) {
    _pwm_value = 255;
  }
  analogWrite(_pwm_pin, _pwm_value);
}

void MotorEncoder::enc_interrupt() {
  boolean enc_a = digitalRead(_enc_a_pin);
  boolean enc_b = digitalRead(_enc_b_pin);
  if (enc_a != _enc_a_last) {
    if (enc_b != enc_a) {
      _enc_count++;
    } else {
      _enc_count--;
    }
  }
  _enc_a_last = enc_a;
}

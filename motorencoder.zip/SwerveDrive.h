#include <Arduino.h>

class SwerveDrive {
  public:
    SwerveDrive(int left_dir_pin, int left_pwm_pin, int left_enc_a_pin, int left_enc_b_pin,
                int right_dir_pin, int right_pwm_pin, int right_enc_a_pin, int right_enc_b_pin);
    void set_target_velocity(float target_linear_velocity, float target_angular_velocity);
    void control_motors();

  private:
    MotorEncoder _left_motor;
    MotorEncoder _right_motor;
    float _wheelbase;
    const float _wheel_radius = 0.05;  // radius of each wheel in meters
};

SwerveDrive::SwerveDrive(int left_dir_pin, int left_pwm_pin, int left_enc_a_pin, int left_enc_b_pin,
                         int right_dir_pin, int right_pwm_pin, int right_enc_a_pin, int right_enc_b_pin) :
    _left_motor(left_dir_pin, left_pwm_pin, left_enc_a_pin, left_enc_b_pin),
    _right_motor(right_dir_pin, right_pwm_pin, right_enc_a_pin, right_enc_b_pin)
{
  _wheelbase = 0.2;  // distance between the wheels in meters
}

void SwerveDrive::set_target_velocity(float target_linear_velocity, float target_angular_velocity) {
  float left_velocity = (2 * target_linear_velocity - target_angular_velocity * _wheelbase) / (2 * _wheel_radius);
  float right_velocity = (2 * target_linear_velocity + target_angular_velocity * _wheelbase) / (2 * _wheel_radius);
  _left_motor.set_target_velocity(left_velocity);
  _right_motor.set_target_velocity(right_velocity);
}

void SwerveDrive::control_motors() {
  _left_motor.control_motor();
  _right_motor.control_motor();
}
